export const PLATFORMS = ["All", "Netflix", "Prime Video", "Disney+", "HBO Max", "Hulu", "Theater"];
export const STATUS = ["All", "Watching", "Completed", "Plan to Watch", "Dropped"];
export const GENRES = ["Action", "Drama", "Comedy", "Thriller", "Sci-Fi", "Romance", "Fantasy"];
export const CATEGORIES = ["All Languages", "Tamil", "Telugu", "Bollywood", "Hollywood", "Dramas"];
export const POSTERS = ["🎬","⚔️","⛓️","🤖","🎧","🦁","📷","🌾","🔫","👓","👺","🐘","🏹","🐯","🪵","🕶️","🪰","🐎","🏠","🏏","🚲","🎓","🤼","🧨","📻","🩺","🧒","🚗","🎞️","🚁","🛡️","🚢","🦇","🌀","🚀","🌊","🦖","🕷️","🧱","🏃","💼","👊","🧠","🐁","🍑","🤡","🥁"];

export const INITIAL_SHOWS = [
  // --- TAMIL ---
  { id: 1, title: "Vikram", platform: "Disney+", status: "Completed", category: "Tamil", genre: "Action", rating: 9, year: 2022, poster: "⚔️", color: "#7c6af7", link: "https://www.imdb.com/title/tt13403046/", cast: "Kamal Haasan, Vijay Sethupathi" },
  { id: 2, title: "Jailer", platform: "Prime Video", status: "Completed", category: "Tamil", genre: "Action", rating: 9, year: 2023, poster: "⛓️", color: "#7c6af7", link: "https://www.imdb.com/title/tt20270500/", cast: "Rajinikanth, Vinayakan" },
  { id: 3, title: "Master", platform: "Prime Video", status: "Completed", category: "Tamil", genre: "Action", rating: 8, year: 2021, poster: "🎧", color: "#7c6af7", link: "https://www.imdb.com/title/tt11057302/", cast: "Vijay, Vijay Sethupathi" },
  { id: 4, title: "Kaithi", platform: "Disney+", status: "Completed", category: "Tamil", genre: "Thriller", rating: 9, year: 2019, poster: "🚚", color: "#7c6af7", link: "https://www.imdb.com/title/tt10300344/", cast: "Karthi" },
  { id: 5, title: "Enthiran", platform: "Prime Video", status: "Completed", category: "Tamil", genre: "Sci-Fi", rating: 8, year: 2010, poster: "🤖", color: "#7c6af7", link: "https://www.imdb.com/title/tt1305797/", cast: "Rajinikanth" },
  { id: 6, title: "96", platform: "Netflix", status: "Completed", category: "Tamil", genre: "Romance", rating: 10, year: 2018, poster: "📷", color: "#7c6af7", link: "https://www.imdb.com/title/tt7019842/", cast: "Vijay Sethupathi, Trisha" },
  { id: 7, title: "Asuran", platform: "Prime Video", status: "Completed", category: "Tamil", genre: "Drama", rating: 10, year: 2019, poster: "🌾", color: "#7c6af7", link: "https://www.imdb.com/title/tt9708358/", cast: "Dhanush" },
  { id: 8, title: "Thuppakki", platform: "Disney+", status: "Completed", category: "Tamil", genre: "Action", rating: 9, year: 2012, poster: "🔫", color: "#7c6af7", link: "https://www.imdb.com/title/tt2192923/", cast: "Vijay" },
  { id: 9, title: "Sivaji: The Boss", platform: "Netflix", status: "Completed", category: "Tamil", genre: "Action", rating: 9, year: 2007, poster: "👓", color: "#7c6af7", link: "https://www.imdb.com/title/tt0479751/", cast: "Rajinikanth" },
  { id: 10, title: "Anniyan", platform: "Prime Video", status: "Completed", category: "Tamil", genre: "Thriller", rating: 10, year: 2005, poster: "👺", color: "#7c6af7", link: "https://www.imdb.com/title/tt0456156/", cast: "Vikram" },

  // --- TELUGU ---
  { id: 11, title: "RRR", platform: "Netflix", status: "Completed", category: "Telugu", genre: "Action", rating: 10, year: 2022, poster: "🐯", color: "#fab005", link: "https://www.imdb.com/title/tt8178634/", cast: "Ram Charan, Jr NTR" },
  { id: 12, title: "Baahubali", platform: "Netflix", status: "Completed", category: "Telugu", genre: "Fantasy", rating: 10, year: 2015, poster: "🏹", color: "#fab005", link: "https://www.imdb.com/title/tt2631186/", cast: "Prabhas" },
  { id: 13, title: "Pushpa: The Rise", platform: "Prime Video", status: "Completed", category: "Telugu", genre: "Action", rating: 8, year: 2021, poster: "🪵", color: "#fab005", link: "https://www.imdb.com/title/tt12027020/", cast: "Allu Arjun" },
  { id: 14, title: "Arjun Reddy", platform: "Prime Video", status: "Completed", category: "Telugu", genre: "Drama", rating: 9, year: 2017, poster: "🕶️", color: "#fab005", link: "https://www.imdb.com/title/tt7294534/", cast: "Vijay Deverakonda" },
  { id: 15, title: "Eega", platform: "Netflix", status: "Completed", category: "Telugu", genre: "Fantasy", rating: 9, year: 2012, poster: "🪰", color: "#fab005", link: "https://www.imdb.com/title/tt2258337/", cast: "Nani, Samantha" },

  // --- BOLLYWOOD ---
  { id: 21, title: "3 Idiots", platform: "Netflix", status: "Completed", category: "Bollywood", genre: "Comedy", rating: 10, year: 2009, poster: "🎓", color: "#339af0", link: "https://www.imdb.com/title/tt1187043/", cast: "Aamir Khan" },
  { id: 22, title: "Dangal", platform: "Netflix", status: "Completed", category: "Bollywood", genre: "Action", rating: 10, year: 2016, poster: "🤼", color: "#339af0", link: "https://www.imdb.com/title/tt5074352/", cast: "Aamir Khan" },
  { id: 23, title: "Sholay", platform: "Prime Video", status: "Completed", category: "Bollywood", genre: "Action", rating: 10, year: 1975, poster: "🧨", color: "#339af0", link: "https://www.imdb.com/title/tt0073707/", cast: "Amitabh Bachchan" },
  { id: 24, title: "PK", platform: "Netflix", status: "Completed", category: "Bollywood", genre: "Comedy", rating: 9, year: 2014, poster: "📻", color: "#339af0", link: "https://www.imdb.com/title/tt2338151/", cast: "Aamir Khan" },

  // --- HOLLYWOOD ---
  { id: 31, title: "Avengers: Endgame", platform: "Disney+", status: "Completed", category: "Hollywood", genre: "Action", rating: 10, year: 2019, poster: "🛡️", color: "#38d9a9", link: "https://www.imdb.com/title/tt4154796/", cast: "Robert Downey Jr" },
  { id: 32, title: "The Dark Knight", platform: "Netflix", status: "Completed", category: "Hollywood", genre: "Action", rating: 10, year: 2008, poster: "🦇", color: "#38d9a9", link: "https://www.imdb.com/title/tt0468569/", cast: "Christian Bale" },

  // --- WATCHLIST (PLAN TO WATCH) ---
  { id: 50, title: "Inception", platform: "Netflix", status: "Plan to Watch", category: "Hollywood", genre: "Sci-Fi", rating: 10, year: 2010, poster: "🌀", color: "#38d9a9", link: "https://www.imdb.com/title/tt1375666/", cast: "Leonardo DiCaprio" },
  { id: 51, title: "Kalki 2898 AD", platform: "Theater", status: "Plan to Watch", category: "Telugu", genre: "Sci-Fi", rating: 9, year: 2024, poster: "🤖", color: "#fab005", link: "https://www.imdb.com/title/tt12713918/", cast: "Prabhas, Amitabh Bachchan" },
  { id: 52, title: "Leo", platform: "Netflix", status: "Plan to Watch", category: "Tamil", genre: "Action", rating: 8, year: 2023, poster: "🦁", color: "#7c6af7", link: "https://www.imdb.com/title/tt15654328/", cast: "Vijay" },
  { id: 53, title: "Devara", platform: "Theater", status: "Plan to Watch", category: "Telugu", genre: "Action", rating: 8, year: 2024, poster: "🌊", color: "#fab005", link: "https://www.imdb.com/title/tt14517316/", cast: "Jr NTR" }
];