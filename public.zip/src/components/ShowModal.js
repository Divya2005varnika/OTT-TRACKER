import React, { useState } from "react";
import { CATEGORIES, STATUS } from "../data/constants";

export default function ShowModal({ onSave, onClose }) {
  const [form, setForm] = useState({
    title: "", category: "Tamil", status: "Plan to Watch", 
    genre: "Action", year: 2024, rating: 10, poster: "🎬", link: "", cast: ""
  });

  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <h2>Add to Library</h2>
        <input type="text" placeholder="Movie Title" required onChange={e => setForm({...form, title: e.target.value})} />
        <input type="text" placeholder="Cast Names" onChange={e => setForm({...form, cast: e.target.value})} />
        <input type="text" placeholder="IMDb Link" onChange={e => setForm({...form, link: e.target.value})} />
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          <select onChange={e => setForm({...form, category: e.target.value})}>
            {CATEGORIES.slice(1).map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select value={form.status} onChange={e => setForm({...form, status: e.target.value})}>
            {STATUS.slice(1).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="modal-actions" style={{ marginTop: '20px' }}>
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={() => onSave(form)}>Save Show</button>
        </div>
      </div>
    </div>
  );
}