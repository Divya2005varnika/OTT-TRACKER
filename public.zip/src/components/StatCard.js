import React from "react";

const StatCard = ({ num, label, color }) => (
  <div className="stat-card" style={{ "--accent-color": color }}>
    <div className="stat-num">{num}</div>
    <div className="stat-label">{label}</div>
  </div>
);
export default StatCard;