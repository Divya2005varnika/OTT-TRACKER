import React from "react";

const ShowCard = ({ show, onClick }) => {
  return (
    <div className="show-card" onClick={onClick}>
      <div className="card-banner" style={{ background: `linear-gradient(135deg, ${show.color}22, ${show.color}44)` }}>
        <span style={{ fontSize: "4rem" }}>{show.poster}</span>
      </div>
      <div className="card-body">
        <div className="card-title">{show.title}</div>
        <div className="card-meta">{show.genre} | {show.year}</div>
        <div className="rating-display">⭐ {show.rating}/10</div>
      </div>
    </div>
  );
};

export default ShowCard;