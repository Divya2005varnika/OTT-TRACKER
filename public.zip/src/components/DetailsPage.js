import React from "react";

export default function DetailsPage({ movie, onBack }) {
  return (
    <div className="details-view view-fade">
      <button className="btn-ghost" onClick={onBack} style={{ marginBottom: '20px' }}>← Back</button>
      <div className="details-card">
        <div className="details-poster" style={{ fontSize: '12rem' }}>{movie.poster}</div>
        <div className="details-info">
          <h1>{movie.title}</h1>
          <p className="details-subtitle">{movie.year} | {movie.genre} | {movie.category}</p>
          <div className="info-section" style={{ marginTop: '20px' }}>
            <h4 style={{ color: '#94a3b8', textTransform: 'uppercase', fontSize: '0.8rem' }}>Movie Cast</h4>
            <p>{movie.cast || "No cast info available."}</p>
          </div>
          <a href={movie.link} target="_blank" rel="noreferrer" className="btn-primary" style={{ display: 'inline-block', marginTop: '20px', textDecoration: 'none' }}>
            View on IMDb ↗
          </a>
        </div>
      </div>
    </div>
  );
}