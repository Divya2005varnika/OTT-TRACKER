import React, { useReducer, useState } from "react";
import "./styles.css";
import { INITIAL_SHOWS, CATEGORIES } from "./data/constants";
import { reducer, initialState } from "./reducer/reducer";

import ShowCard from "./components/ShowCard";
import DetailsPage from "./components/DetailsPage";
import AnalyticsPage from "./components/AnalyticsPage";
import ShowModal from "./components/ShowModal";

export default function App() {
  const [view, setView] = useState("LOGIN"); 
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [modal, setModal] = useState(null);
  const [darkMode, setDarkMode] = useState(true);
  
  const [state, dispatch] = useReducer(reducer, { ...initialState, shows: INITIAL_SHOWS });
  const { filter, sort, shows } = state;

  const stats = {
    total: shows.length,
    watching: shows.filter(s => s.status === "Watching").length,
    completed: shows.filter(s => s.status === "Completed").length,
    epsWatched: shows.reduce((acc, curr) => acc + curr.watched, 0)
  };

  const filtered = shows
    .filter(s => (filter.category === "All Languages" || s.category === filter.category))
    .filter(s => (!filter.search || s.title.toLowerCase().includes(filter.search.toLowerCase())))
    .sort((a, b) => (sort === "rating" ? b.rating - a.rating : a.title.localeCompare(b.title)));

  if (view === "LOGIN") {
    return (
      <div className="login-page">
        <div className="login-card">
          <h1>OTT<span>TRACK</span></h1>
          <p>Sign in to manage your library</p>
          <input type="text" placeholder="Username" />
          <input type="password" placeholder="Password" />
          <button className="btn-login" onClick={() => setView("HOME")}>Sign In</button>
        </div>
      </div>
    );
  }

  return (
    <div className={`app-container ${darkMode ? "dark" : "light"}`}>
      {/* STICKY NAVBAR */}
      <nav className="navbar">
        <div className="nav-logo" onClick={() => setView("HOME")}>OTT<span>Track</span></div>
        <div className="nav-links">
          <button onClick={() => setView("HOME")}>Home</button>
          <button onClick={() => setView("TRACKER")}>Tracker</button>
          <button onClick={() => setView("WATCHLIST")}>Watchlist</button>
          <button onClick={() => setView("ANALYTICS")}>Analytics</button>
          <button onClick={() => setView("PROFILE")}>Profile</button>
        </div>
        <button className="theme-toggle" onClick={() => setDarkMode(!darkMode)}>{darkMode ? "☀️" : "🌙"}</button>
      </nav>

      <main className="main-content">
        {/* VIEW: HOME / DASHBOARD */}
        {view === "HOME" && (
          <div className="view-fade">
            <div className="hero-section">
              <h1>Welcome Back!</h1>
              <div className="quick-stats">
                <span>📊 {stats.total} Shows</span>
                <span>🎬 {stats.watching} Watching</span>
                <span>✅ {stats.completed} Done</span>
              </div>
            </div>
            <h2>Continue Watching</h2>
            <div className="horizontal-scroll">
              {shows.filter(s => s.status === "Watching").map(s => (
                <ShowCard key={s.id} show={s} onClick={() => { setSelectedMovie(s); setView("DETAILS"); }} />
              ))}
            </div>
            <h2>Recently Added</h2>
            <div className="movie-grid">
              {shows.slice(0, 4).map(s => (
                <ShowCard key={s.id} show={s} onClick={() => { setSelectedMovie(s); setView("DETAILS"); }} />
              ))}
            </div>
          </div>
        )}

        {/* VIEW: TRACKER */}
        {view === "TRACKER" && (
          <div className="view-fade">
            <div className="toolbar-pro">
              <input placeholder="Search library..." onChange={e => dispatch({type: "SET_FILTER", payload: {search: e.target.value}})} />
              <select onChange={e => dispatch({type: "SET_FILTER", payload: {category: e.target.value}})}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <button className="btn-primary" onClick={() => setModal("add")}>+ Add Show</button>
            </div>
            <div className="movie-grid">
              {filtered.map(s => <ShowCard key={s.id} show={s} onClick={() => { setSelectedMovie(s); setView("DETAILS"); }} />)}
            </div>
          </div>
        )}

        {/* VIEW: ANALYTICS */}
        {view === "ANALYTICS" && <AnalyticsPage shows={shows} />}

        {/* VIEW: PROFILE */}
        {view === "PROFILE" && (
          <div className="profile-view">
            <div className="profile-header">
              <div className="avatar">👤</div>
              <h2>Administrator</h2>
              <button className="btn-login" onClick={() => setView("LOGIN")}>Logout</button>
            </div>
            <div className="stat-box">Total Watch Time: {stats.epsWatched} Episodes</div>
          </div>
        )}

        {/* VIEW: WATCHLIST */}
        {view === "WATCHLIST" && (
          <div className="view-fade">
            <h1>My Watchlist ❤️</h1>
            <div className="movie-grid">
              {shows.filter(s => s.status === "Plan to Watch").map(s => (
                <ShowCard key={s.id} show={s} onClick={() => { setSelectedMovie(s); setView("DETAILS"); }} />
              ))}
            </div>
          </div>
        )}

        {view === "DETAILS" && <DetailsPage movie={selectedMovie} onBack={() => setView("HOME")} />}
      </main>

      {modal && <ShowModal onSave={(m) => { dispatch({type:"ADD_SHOW", payload:m}); setModal(null); }} onClose={() => setModal(null)} />}
    </div>
  );
}