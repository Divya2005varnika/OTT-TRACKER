export const initialState = { 
  shows: [], 
  filter: { platform: "All", category: "All Languages", search: "" }, 
  sort: "alphabetical", 
  activeTab: "tracker" 
};

export function reducer(state, action) {
  switch (action.type) {
    case "ADD_SHOW": 
      return { ...state, shows: [...state.shows, { ...action.payload, id: Date.now() }] };
    case "SET_FILTER": 
      return { ...state, filter: { ...state.filter, ...action.payload } };
    case "SET_SORT": 
      return { ...state, sort: action.payload };
    default: 
      return state;
  }
}